BetterDesk Agent bundle (Windows)

CONTENTS
  betterdesk-agent.exe         CLI/service agent (CDAP + proof enrollment sidecar)
  betterdesk-agent-client.exe  Tauri GUI/tray client (if included)
  install.ps1                  zero-config installer (SYSTEM service + autostart + firewall)
  install.sh                   Linux/macOS variant of the bundle installer
  agent-config.json.example    all URLs pre-seeded

INSTALL
  PowerShell (auto-elevates):
    powershell -ExecutionPolicy Bypass -File .\install.ps1
  Or use the MSI from the same release if you prefer a packaged installer.

SMARTSCREEN (unsigned builds)
  Files extracted from this zip may inherit Mark-of-the-Web (Explorer keeps
  the Zone.Identifier). If Windows flags an extracted binary: right-click it >
  Properties > Unblock > OK. Self-extracting via PowerShell Expand-Archive
  drops the flag automatically.
  Installing from the .iso container avoids this entirely - Explorer mounts
  a disk image without propagating MotW onto inner files:
    right-click > Mount > run install.ps1 from the mounted drive.

SIGNED releases clear the prompt once the certificate has been seen twice
(SmartScreen reputation). Ask the console admin for the signed build.
